// Fallback text extraction function that doesn't rely on PDF.js
export async function extractTextWithoutPdfJs(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = () => {
      try {
        // For text files, just return the content
        const text = reader.result as string
        resolve(text)
      } catch (error) {
        reject(new Error("Failed to extract text from file. Please try a different file format."))
      }
    }
    reader.onerror = () => {
      reject(new Error("Error reading file"))
    }
    reader.readAsText(file)
  })
}

// Initialize PDF.js
export async function initPdfJs() {
  if (typeof window !== "undefined") {
    // Use dynamic import instead of require
    const pdfjs = await import("pdfjs-dist/legacy/build/pdf")
    pdfjs.GlobalWorkerOptions.workerSrc = "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/5.2.133/pdf.worker.min.js"
    return pdfjs
  }
  return null
}
