"use client"

// This file is kept as a placeholder to maintain compatibility with any code that might import from it
// All OpenRouter references have been removed

// Placeholder for any code that might import openai
export const openai = {
  // Empty placeholder
}

// Helper function to generate text (placeholder)
export async function generateText({
  model,
  prompt,
  temperature = 0.7,
  maxTokens = 1000,
}: {
  model: any
  prompt: string
  temperature?: number
  maxTokens?: number
}) {
  console.warn("generateText in openai.ts is deprecated - please use Gemini API directly instead")

  try {
    // Return a placeholder response
    return { text: "This function is deprecated. Please use Gemini API directly." }
  } catch (error) {
    console.error("Error generating text:", error)
    throw error
  }
}
