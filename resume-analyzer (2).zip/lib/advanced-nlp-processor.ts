"use client"

import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"
import { extractEntities } from "./nlp-processor"

// Advanced NLP processor that uses more sophisticated models
export class AdvancedNLPProcessor {
  // Process text with advanced NLP techniques
  static async processText(text: string) {
    // First use the basic processor for quick results
    const basicResults = extractEntities(text)

    // Then enhance with more sophisticated analysis
    const enhancedResults = await this.enhanceWithAI(text, basicResults)

    return enhancedResults
  }

  // Enhance basic results with AI-powered analysis
  private static async enhanceWithAI(text: string, basicResults: any) {
    try {
      // Use the AI SDK to generate enhanced analysis
      const { text: enhancedAnalysis } = await generateText({
        model: openai("gpt-4o"),
        prompt: this.createEnhancementPrompt(text, basicResults),
        temperature: 0.2,
        maxTokens: 1500,
      })

      // Parse the enhanced analysis
      const enhancedData = JSON.parse(enhancedAnalysis)

      // Merge with basic results, preferring enhanced data
      return {
        ...basicResults,
        ...enhancedData,
        skills: [...new Set([...basicResults.skills, ...enhancedData.skills])],
        jobTitles: [...new Set([...basicResults.jobTitles, ...enhancedData.jobTitles])],
        organizations: [...new Set([...basicResults.organizations, ...enhancedData.organizations])],
        // Add new fields from enhanced analysis
        softSkills: enhancedData.softSkills || [],
        technicalSkills: enhancedData.technicalSkills || [],
        achievements: enhancedData.achievements || [],
        educationDetails: enhancedData.educationDetails || [],
        certifications: enhancedData.certifications || [],
        // Add confidence scores
        confidenceScores: enhancedData.confidenceScores || {},
      }
    } catch (error) {
      console.error("Error enhancing with AI:", error)
      // Fall back to basic results if AI enhancement fails
      return {
        ...basicResults,
        softSkills: [],
        technicalSkills: basicResults.skills,
        achievements: [],
        educationDetails: [],
        certifications: [],
        confidenceScores: {},
      }
    }
  }

  // Create a prompt for the AI to enhance the basic analysis
  private static createEnhancementPrompt(text: string, basicResults: any) {
    return `Analyze the following text from a resume and extract detailed information beyond the basic entities already identified.

Basic entities already identified:
- Skills: ${JSON.stringify(basicResults.skills)}
- Job Titles: ${JSON.stringify(basicResults.jobTitles)}
- Organizations: ${JSON.stringify(basicResults.organizations)}
- People: ${JSON.stringify(basicResults.people)}
- Dates: ${JSON.stringify(basicResults.dates)}

Please provide a more sophisticated analysis including:
1. Technical skills with proficiency level estimation (beginner, intermediate, expert)
2. Soft skills demonstrated in achievements or responsibilities
3. Detailed achievements with quantifiable metrics
4. Education details including degrees, institutions, and graduation dates
5. Certifications and professional qualifications
6. Career progression patterns
7. Areas of expertise and specialization

Resume text:
${text}

Respond with a JSON object containing these categories. For each identified entity, include a confidence score between 0 and 1.`
  }

  // Extract semantic relationships between entities
  static async extractRelationships(text: string) {
    try {
      const { text: relationshipsJson } = await generateText({
        model: openai("gpt-4o"),
        prompt: `Analyze the following resume text and extract semantic relationships between entities.
        For example:
        - Person X worked at Company Y from Date Z
        - Person X used Technology Y on Project Z
        - Person X reported to Person Y
        - Person X earned Degree Y from Institution Z
        
        Resume text:
        ${text}
        
        Return the relationships as a JSON array of objects with "subject", "predicate", "object", and "confidence" properties.`,
        temperature: 0.2,
        maxTokens: 1000,
      })

      return JSON.parse(relationshipsJson)
    } catch (error) {
      console.error("Error extracting relationships:", error)
      return []
    }
  }

  // Perform semantic matching between resume and job description
  static async semanticMatch(resumeText: string, jobDescriptionText: string) {
    try {
      const { text: matchingJson } = await generateText({
        model: openai("gpt-4o"),
        prompt: `Compare the following resume and job description using semantic understanding.
        Identify matches beyond exact keyword matching, considering:
        - Semantic similarity of skills and experiences
        - Equivalent technologies and tools
        - Transferable skills and experiences
        - Implicit qualifications
        
        Resume:
        ${resumeText}
        
        Job Description:
        ${jobDescriptionText}
        
        Return a JSON object with:
        1. "matches": Array of matched items with "resumeText", "jobText", "matchType" (exact, semantic, partial), and "confidence"
        2. "missingRequirements": Array of job requirements not found in the resume
        3. "relevantExperiences": Array of resume experiences relevant to the job
        4. "overallMatchScore": A score from 0-100 representing semantic match quality`,
        temperature: 0.2,
        maxTokens: 2000,
      })

      return JSON.parse(matchingJson)
    } catch (error) {
      console.error("Error performing semantic matching:", error)
      return {
        matches: [],
        missingRequirements: [],
        relevantExperiences: [],
        overallMatchScore: 0,
      }
    }
  }
}

// Export a singleton instance for easy imports
export const advancedNLPProcessor = new AdvancedNLPProcessor()
