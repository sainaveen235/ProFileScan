"use client"

import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"

export class DomainSpecificNER {
  // Extract domain-specific entities from text
  static async extractEntities(
    text: string,
    domain: string,
  ): Promise<{
    entities: Record<string, string[]>
    relationships: Array<{ subject: string; predicate: string; object: string; confidence: number }>
  }> {
    try {
      const { text: entitiesJson } = await generateText({
        model: openai("gpt-4o"),
        prompt: `Extract domain-specific entities from the following text for the ${domain} domain.
        
        Identify entities such as:
        1. Domain-specific technical terms
        2. Industry-specific methodologies
        3. Domain-specific tools and technologies
        4. Domain-specific metrics and KPIs
        5. Domain-specific roles and responsibilities
        
        Also identify relationships between these entities.
        
        Text:
        ${text}
        
        Return a JSON object with:
        1. "entities": An object where keys are entity types and values are arrays of entity strings
        2. "relationships": An array of objects with "subject", "predicate", "object", and "confidence" properties`,
        temperature: 0.1,
        maxTokens: 2000,
      })

      return JSON.parse(entitiesJson)
    } catch (error) {
      console.error("Error extracting domain-specific entities:", error)
      return {
        entities: {},
        relationships: [],
      }
    }
  }

  // Get domain-specific entity types for a given domain
  static getDomainEntityTypes(domain: string): string[] {
    const commonTypes = ["Technical Terms", "Methodologies", "Tools", "Metrics", "Roles"]

    // Add domain-specific entity types
    switch (domain.toLowerCase()) {
      case "software development":
        return [...commonTypes, "Programming Languages", "Frameworks", "Design Patterns", "Development Methodologies"]
      case "data science":
        return [...commonTypes, "Algorithms", "Statistical Methods", "Data Sources", "Visualization Techniques"]
      case "healthcare":
        return [...commonTypes, "Medical Terms", "Procedures", "Regulations", "Patient Care"]
      case "finance":
        return [...commonTypes, "Financial Instruments", "Regulations", "Market Terms", "Risk Metrics"]
      case "marketing":
        return [...commonTypes, "Channels", "Campaign Types", "Audience Segments", "Conversion Metrics"]
      default:
        return commonTypes
    }
  }

  // Extract domain-specific achievements
  static async extractAchievements(
    text: string,
    domain: string,
  ): Promise<Array<{ achievement: string; impact: string; metrics: string; confidence: number }>> {
    try {
      const { text: achievementsJson } = await generateText({
        model: openai("gpt-4o"),
        prompt: `Extract domain-specific achievements from the following text for the ${domain} domain.
        
        Focus on:
        1. Concrete accomplishments
        2. Measurable impact
        3. Domain-specific metrics and KPIs
        4. Technical or business challenges overcome
        
        Text:
        ${text}
        
        Return a JSON array of objects with "achievement", "impact", "metrics", and "confidence" properties.`,
        temperature: 0.1,
        maxTokens: 2000,
      })

      return JSON.parse(achievementsJson)
    } catch (error) {
      console.error("Error extracting domain-specific achievements:", error)
      return []
    }
  }

  // Analyze domain-specific competency
  static async analyzeCompetency(
    resumeText: string,
    jobDescriptionText: string,
    domain: string,
  ): Promise<{
    overallScore: number
    strengths: string[]
    gaps: string[]
    recommendations: string[]
  }> {
    try {
      const { text: analysisJson } = await generateText({
        model: openai("gpt-4o"),
        prompt: `Analyze domain-specific competency for the ${domain} domain by comparing the resume to the job description.
        
        Resume:
        ${resumeText}
        
        Job Description:
        ${jobDescriptionText}
        
        Evaluate:
        1. Overall domain competency score (0-100)
        2. Domain-specific strengths
        3. Domain-specific gaps
        4. Recommendations for improving domain-specific competency
        
        Return a JSON object with "overallScore", "strengths", "gaps", and "recommendations" properties.`,
        temperature: 0.2,
        maxTokens: 2000,
      })

      return JSON.parse(analysisJson)
    } catch (error) {
      console.error("Error analyzing domain-specific competency:", error)
      return {
        overallScore: 0,
        strengths: [],
        gaps: [],
        recommendations: [],
      }
    }
  }
}
