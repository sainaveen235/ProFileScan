"use client"

// Import a specific version of PDF.js to ensure consistency
import * as pdfjs from "pdfjs-dist/legacy/build/pdf"

// Initialize PDF.js worker with a fixed version number that matches the API version
if (typeof window !== "undefined") {
  pdfjs.GlobalWorkerOptions.workerSrc = "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/5.2.133/pdf.worker.min.js"
}

export async function extractTextFromPDF(file: File): Promise<string> {
  try {
    // Check if we're in a browser environment
    if (typeof window === "undefined") {
      throw new Error("PDF extraction is only available in browser environment")
    }

    // Use FileReader to read the file as a data URL to prevent ArrayBuffer detachment
    const dataUrl = await new Promise<string>((resolve, reject) => {
      const reader = new FileReader()
      reader.onload = () => resolve(reader.result as string)
      reader.onerror = reject
      reader.readAsDataURL(file)
    })

    // Load the PDF document from the data URL
    const pdf = await pdfjs.getDocument({
      url: dataUrl,
      cMapUrl: "https://unpkg.com/pdfjs-dist@5.2.133/cmaps/",
      cMapPacked: true,
    }).promise

    let fullText = ""

    // Extract text from each page
    for (let i = 1; i <= pdf.numPages; i++) {
      const page = await pdf.getPage(i)
      const textContent = await page.getTextContent()
      const pageText = textContent.items.map((item: any) => item.str).join(" ")
      fullText += pageText + "\n"
    }

    return fullText
  } catch (error) {
    console.error("Error extracting text from PDF:", error)
    throw error
  }
}
