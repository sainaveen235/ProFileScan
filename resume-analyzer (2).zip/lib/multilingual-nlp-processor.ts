"use client"

import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"
import { AdvancedNLPProcessor } from "./advanced-nlp-processor"

export class MultilingualNLPProcessor {
  // Detect the language of the text
  static async detectLanguage(text: string): Promise<{
    language: string
    languageCode: string
    confidence: number
  }> {
    try {
      const { text: languageJson } = await generateText({
        model: openai("gpt-4o"),
        prompt: `Detect the language of the following text. Return a JSON object with:
        1. "language": The full name of the language (e.g., "English", "Spanish", "French")
        2. "languageCode": The ISO 639-1 language code (e.g., "en", "es", "fr")
        3. "confidence": A number between 0 and 1 indicating your confidence in the detection
        
        Text:
        ${text.substring(0, 1000)}`,
        temperature: 0.1,
        maxTokens: 100,
      })

      return JSON.parse(languageJson)
    } catch (error) {
      console.error("Error detecting language:", error)
      // Default to English if detection fails
      return {
        language: "English",
        languageCode: "en",
        confidence: 0.5,
      }
    }
  }

  // Translate text to English for processing
  static async translateToEnglish(text: string, sourceLanguage: string): Promise<string> {
    if (sourceLanguage === "en") return text

    try {
      const { text: translatedText } = await generateText({
        model: openai("gpt-4o"),
        prompt: `Translate the following text from ${sourceLanguage} to English, preserving formatting and technical terms:
        
        ${text}`,
        temperature: 0.1,
        maxTokens: 4000,
      })

      return translatedText
    } catch (error) {
      console.error("Error translating text:", error)
      return text // Return original text if translation fails
    }
  }

  // Process text in any language
  static async processText(text: string): Promise<any> {
    try {
      // Detect language
      const languageInfo = await this.detectLanguage(text)

      // If not English, translate to English for processing
      let processedText = text
      if (languageInfo.languageCode !== "en") {
        processedText = await this.translateToEnglish(text, languageInfo.languageCode)
      }

      // Process the text with the advanced NLP processor
      const results = await AdvancedNLPProcessor.processText(processedText)

      // Add language information to results
      return {
        ...results,
        languageInfo,
      }
    } catch (error) {
      console.error("Error in multilingual processing:", error)
      // Fall back to basic processing
      return AdvancedNLPProcessor.processText(text)
    }
  }

  // Translate results back to original language if needed
  static async translateResults(results: any, targetLanguage: string): Promise<any> {
    if (targetLanguage === "en") return results

    try {
      const { text: translatedJson } = await generateText({
        model: openai("gpt-4o"),
        prompt: `Translate the following JSON object from English to ${targetLanguage}. 
        Only translate string values that represent human-readable text (e.g., summaries, comments, descriptions).
        Do not translate technical terms, names, or identifiers.
        
        ${JSON.stringify(results, null, 2)}
        
        Return the translated JSON object.`,
        temperature: 0.1,
        maxTokens: 4000,
      })

      return JSON.parse(translatedJson)
    } catch (error) {
      console.error("Error translating results:", error)
      return results // Return original results if translation fails
    }
  }
}
